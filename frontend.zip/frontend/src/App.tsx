import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Spin } from 'antd';
import MainLayout from './layouts/MainLayout';
import {
  LoginPage,
  DashboardPage,
  DashboardDetailPage,
  ExecutiveDashboardPage,
  IntroPage, ProfilePage,
  UserManagementPage,
  ActivityLogPage,
  ProductsPage,
  CategoriesPage,
  CustomersPage,
  SuppliersPage,
  WarehousesPage,
  StockBalancePage,
  SalesInvoicesPage,
  PurchaseOrdersPage,
  GoodsReceiptsPage,
  StockIssuesPage,
  StockTransfersPage,
  StockAdjustmentsPage,
  StockCountsPage,
  QuotationList,
  QuotationForm,
  QuotationDetail,
  UserSettingsPage,
  CompanySettingsPage,
} from './pages';
import StockCardPage from './pages/StockCardPage';
import StockValuationPage from './pages/StockValuationPage';
import StockMovementPage from './pages/StockMovementPage';
import ReorderAlertPage from './pages/ReorderAlertPage';
import ExpiryAlertPage from './pages/ExpiryAlertPage';
import SerialNumberPage from './pages/SerialNumberPage';
import BarcodeScannerPage from './pages/BarcodeScannerPage';
import SettingsPage from './pages/SettingsPage';
import { useAuth } from './contexts/AuthContext';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div
        style={{
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#020617',
        }}
      >
        <Spin size="large" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const App: React.FC = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<LoginPage />} />
      
      {/* Intro Page - No Layout */}
      <Route path="/intro" element={
        <ProtectedRoute>
          <IntroPage />
        </ProtectedRoute>
      } />

      {/* Dashboard Detail - No Layout */}
      <Route path="/dashboard-detail" element={
        <ProtectedRoute>
          <DashboardDetailPage />
        </ProtectedRoute>
      } />

      {/* Executive Dashboard - No Layout (for bank presentation) */}
      <Route path="/executive-dashboard" element={
        <ProtectedRoute>
          <ExecutiveDashboardPage />
        </ProtectedRoute>
      } />

      {/* Protected Routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardPage />} />
        
        {/* Master Data */}
        <Route path="products" element={<ProductsPage />} />
        <Route path="categories" element={<CategoriesPage />} />
        <Route path="customers" element={<CustomersPage />} />
        <Route path="suppliers" element={<SuppliersPage />} />
        <Route path="warehouses" element={<WarehousesPage />} />

        {/* Quotations */}
        <Route path="quotations" element={<QuotationList />} />
        <Route path="quotations/new" element={<QuotationForm />} />
        <Route path="quotations/:id" element={<QuotationDetail />} />
        <Route path="quotations/:id/edit" element={<QuotationForm />} />

        {/* Sales */}
        <Route path="sales-invoices" element={<SalesInvoicesPage />} />

        {/* Purchase */}
        <Route path="purchase-orders" element={<PurchaseOrdersPage />} />
        <Route path="goods-receipts" element={<GoodsReceiptsPage />} />

        {/* Stock */}
        <Route path="stock-balance" element={<StockBalancePage />} />
        <Route path="stock-card" element={<StockCardPage />} />
        <Route path="stock-valuation" element={<StockValuationPage />} />
        <Route path="stock-movement" element={<StockMovementPage />} />
        <Route path="reorder-alerts" element={<ReorderAlertPage />} />
        <Route path="expiry-alerts" element={<ExpiryAlertPage />} />
        <Route path="serial-numbers" element={<SerialNumberPage />} />
        <Route path="barcode-scanner" element={<BarcodeScannerPage />} />
        <Route path="stock-issues" element={<StockIssuesPage />} />
        <Route path="stock-transfers" element={<StockTransfersPage />} />
        <Route path="stock-adjustments" element={<StockAdjustmentsPage />} />
        <Route path="stock-counts" element={<StockCountsPage />} />
        
        {/* Settings */}
        <Route path="settings" element={<SettingsPage />} />
        <Route path="settings/user" element={<UserSettingsPage />} />
        <Route path="settings/company" element={<CompanySettingsPage />} />
        <Route path="admin/users" element={<UserManagementPage />} />
        <Route path="admin/activity-logs" element={<ActivityLogPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default App;

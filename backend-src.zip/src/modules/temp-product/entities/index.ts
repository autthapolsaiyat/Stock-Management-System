export * from './temp-product.entity';
